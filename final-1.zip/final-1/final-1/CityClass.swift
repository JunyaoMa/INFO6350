//
//  CityClass.swift
//  final-1
//
//  Created by Junyao Ma on 12/9/23.
//

import Foundation

class CityClass {
    var cityCode: String = ""
    var city: String = ""
    var temperature: Int = 0
    var conditions: String = ""
    
}
