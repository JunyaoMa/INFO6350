//
//  Constants.swift
//  final-1
//
//  Created by Junyao Ma on 12/9/23.
//

import Foundation

let baseURL = "https://us-central1-fir-api-s-8d31b.cloudfunctions.net/app"
