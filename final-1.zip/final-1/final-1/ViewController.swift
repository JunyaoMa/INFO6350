//
//  ViewController.swift
//  final-1
//
//  Created by Junyao Ma on 12/9/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var cityValues: [CityClass] = [CityClass]()
    var cityNames = ["SEA","SFO", "PDX", "NYC","MIA"]
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func displayWeather(_ sender: Any) {
        var cities = ""
        for city in cityNames {
            cities.append("\(city),")
        }
        let citiesStr = cities.dropLast()
        let url = baseURL
        print(url)
        SwiftSpinner.show("Displaying")
        AF.request(url).responseJSON { response in
            SwiftSpinner.hide()
            if response.error != nil {
                print(response.error?.localizedDescription ?? "Error")
                return
            }
            guard let rawData = response.data else {return}
            guard let jsonArray = JSON(rawData).array else {return}
            
            self.cityValues = [CityClass]()
            for cityJSON in jsonArray {
                print("City : \(cityJSON)")
                let cityCode = cityJSON["cityCode"].stringValue
                let city = cityJSON["city"].stringValue
                let temperature = cityJSON["temperature"].intValue
                let conditions = cityJSON["conditions"].stringValue
                
                let CityClass = CityClass()
                CityClass.cityCode = cityCode
                CityClass.city = city
                CityClass.temperature = temperature
                CityClass.conditions = conditions
                self.cityValues.append(CityClass)
            }
            self.tblView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cityValues.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let cityCode = cityValues[indexPath.row].cityCode
        let city = cityValues[indexPath.row].city
        let temperature = cityValues[indexPath.row].temperature
        let conditions = cityValues[indexPath.row].conditions
        cell.textLabel?.text = "cityCode: \(cityCode) city: \(city) temperature: \(temperature) conditions:\(conditions)"
        return cell
    }
}

